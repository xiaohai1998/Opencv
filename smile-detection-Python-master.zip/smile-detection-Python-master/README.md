# smile-detection-Python
---
Smile detection based on OpenCV implemented in Python

<br/>
<div>
<img src="https://github.com/LiuXiaolong19920720/smile-detection-Python/blob/master/smile.jpg" width="70%">
</div>
<br/>

If you prefer to use C++, you can find a C++ version code here:

[Smile-detection-Cpp](https://github.com/LiuXiaolong19920720/smile-detection-Cpp)

